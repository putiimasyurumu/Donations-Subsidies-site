const light = document.querySelector(".light-rays");

let t = 0;

function animateLight() {
  t += 0.002;

  const x = Math.sin(t) * 20;
  const scale = 1 + Math.sin(t * 0.7) * 0.05;

  light.style.transform = `translateX(${x}px) scale(${scale})`;

  requestAnimationFrame(animateLight);
}

animateLight();
